/**
 * @prettier
 */
const encode8bit = (content) => Buffer.from(content).toString("utf8")

export default encode8bit
